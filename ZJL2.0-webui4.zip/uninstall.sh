# 该脚本将在卸载期间执行，您可以编写自定义卸载规则

# 停止 Web 控制面板
if [ -f /data/clnc/web/httpd.pid ]; then
    kill "$(cat /data/clnc/web/httpd.pid)" 2>/dev/null
fi
# 兜底:按精确特征(-h 工作目录)杀掉残留的面板进程,避免误伤其他进程
for p in $(ps -A -o pid,args 2>/dev/null | grep "[h]ttpd" | grep -F -- "-h /data/clnc/web" | awk '{print $1}'); do
    kill "$p" 2>/dev/null
done

rm -rf /data/clnc/
