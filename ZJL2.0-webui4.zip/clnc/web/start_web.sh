#!/system/bin/sh
# ZJL Web 控制面板启动脚本
# 由 service.sh 在开机时调用；只监听 127.0.0.1，本机浏览器访问
# 端口可改: WEB_PORT=8080 /system/bin/sh /data/clnc/web/start_web.sh

WEBDIR="/data/clnc/web"
WEB_PORT="${WEB_PORT:-8080}"
export PATH="/system/bin:/system/xbin:/vendor/bin:${PATH}"

mkdir -p "$WEBDIR/cgi-bin"

# ---- 找一个带 httpd 的 busybox:优先 Magisk 自带，其次模块自带 ----
BB=""
for b in /data/adb/magisk/busybox /data/adb/ksu/bin/busybox; do
    if [ -x "$b" ] && "$b" --list 2>/dev/null | grep -qx "httpd"; then BB="$b"; break; fi
done
if [ -z "$BB" ]; then
    for b in /data/clnc/*/busybox; do
        if [ -x "$b" ] && "$b" --list 2>/dev/null | grep -qx "httpd"; then BB="$b"; break; fi
    done
fi

echo "=== $(date '+%F %T') start_web ===" >> "$WEBDIR/web.log"
if [ -z "$BB" ]; then
    echo "ERROR: 找不到带 httpd 的 busybox，Web 面板未启动" >> "$WEBDIR/web.log"
    exit 1
fi
echo "busybox: $BB" >> "$WEBDIR/web.log"

# ---- 停掉旧实例 ----
if [ -f "$WEBDIR/httpd.pid" ]; then
    kill "$(cat "$WEBDIR/httpd.pid")" 2>/dev/null
    rm -f "$WEBDIR/httpd.pid"
fi
# 兜底:按精确特征(-h 工作目录)杀掉残留,避免误伤其他进程
for p in $(ps -A -o pid,args 2>/dev/null | grep "[h]ttpd" | grep -F -- "-h /data/clnc/web" | awk '{print $1}'); do
    [ "$p" != "$$" ] && kill "$p" 2>/dev/null
done

# ---- 生成本机 token(每次开机刷新) ----
if [ -r /proc/sys/kernel/random/uuid ]; then
    cat /proc/sys/kernel/random/uuid > "$WEBDIR/.token"
else
    date +%s%N > "$WEBDIR/.token"
fi
chmod 600 "$WEBDIR/.token"

# ---- 启动 httpd:只绑 127.0.0.1,前台运行后转入后台以便记录 pid ----
"$BB" httpd -f -p "127.0.0.1:$WEB_PORT" -h "$WEBDIR" >> "$WEBDIR/web.log" 2>&1 &
echo "$!" > "$WEBDIR/httpd.pid"
echo "listening on 127.0.0.1:$WEB_PORT pid $(cat "$WEBDIR/httpd.pid")" >> "$WEBDIR/web.log"
