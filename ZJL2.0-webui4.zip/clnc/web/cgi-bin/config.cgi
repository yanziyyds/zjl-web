#!/system/bin/sh
# ZJL WebUI:查看/修改防跳配置 (.ini)
. /data/clnc/web/cgi-bin/common.sh

INI=""
for _f in /data/clnc/*.ini; do
    [ -f "$_f" ] && { INI="$_f"; break; }
done

if [ "$REQUEST_METHOD" = "POST" ]; then
    read_post
    TK="$(post_field token)"
    check_token "$TK" || deny
    if [ ! -f "$INI" ]; then
        http_header "text/html"; html_head "出错"
        printf '<p class="bad">找不到配置文件</p>'; html_foot; exit 0
    fi
    cp -f "$INI" "$INI.bak"
    CONTENT="$(post_field content)"
    printf '%s\n' "$CONTENT" > "$INI"
    http_redirect "/cgi-bin/main.cgi?msg=saved"
    exit 0
fi

TOKEN="$(read_token)"
http_header "text/html"
html_head "防跳配置 (.ini)"
if [ ! -f "$INI" ]; then
    printf '<p class="bad">找不到配置文件</p>'
    html_foot; exit 0
fi
printf '<p class="hint">文件：%s（保存前自动备份为 .bak）<br>' "$INI"
printf '保存后需重启防跳生效：<a href="/cgi-bin/main.cgi">回首页点「开启防跳」</a></p>'
printf '<form method="POST" action="/cgi-bin/config.cgi">'
printf '<input type="hidden" name="token" value="%s">' "$TOKEN"
printf '<textarea name="content">'
html_escape < "$INI"
printf '</textarea><br><button type="submit">保存配置</button></form>'
html_foot
