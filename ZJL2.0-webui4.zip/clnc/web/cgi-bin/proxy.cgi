#!/system/bin/sh
# ZJL WebUI:查看/修改代理模式 (.conf,可多选)+ 百度直连 IP 点选
. /data/clnc/web/cgi-bin/common.sh

#  conf 列表(glob 直接遍历,文件名含空格也安全)
SEL="$(query_field f)"
if [ -z "$SEL" ]; then
    for _f in /data/clnc/*.conf; do
        [ -f "$_f" ] && { SEL="$_f"; break; }
    done
fi
# 安全:只允许 /data/clnc/ 下的 .conf
case "$SEL" in
    /data/clnc/*.conf) ;;
    *) SEL=""
       for _f in /data/clnc/*.conf; do
           [ -f "$_f" ] && { SEL="$_f"; break; }
       done ;;
esac

if [ "$REQUEST_METHOD" = "POST" ]; then
    read_post
    TK="$(post_field token)"
    check_token "$TK" || deny
    TARGET="$(post_field file)"
    case "$TARGET" in
        /data/clnc/*.conf) ;;
        *) http_header "text/html"; html_head "出错"; printf '<p class="bad">非法文件路径</p>'; html_foot; exit 0 ;;
    esac
    if [ ! -f "$TARGET" ]; then
        http_header "text/html"; html_head "出错"; printf '<p class="bad">文件不存在</p>'; html_foot; exit 0
    fi
    cp -f "$TARGET" "$TARGET.bak"
    CONTENT="$(post_field content)"
    printf '%s\n' "$CONTENT" > "$TARGET"
    http_redirect "/cgi-bin/proxy.cgi?f=$(urlencode_path "$TARGET")&msg=saved"
    exit 0
fi

TOKEN="$(read_token)"
MSG="$(query_field msg)"
http_header "text/html"
html_head "代理模式 (.conf)"

# 文件选择(glob 直接遍历,文件名含空格也安全)
printf '<div class="tabs">'
for f in /data/clnc/*.conf; do
    [ -f "$f" ] || continue
    bn="${f##*/}"
    fenc="$(urlencode_path "$f")"
    if [ "$f" = "$SEL" ]; then
        printf '<b>%s</b>' "$bn"
    else
        printf '<a href="/cgi-bin/proxy.cgi?f=%s">%s</a>' "$fenc" "$bn"
    fi
done
printf '</div>'

case "$MSG" in
    saved) printf '<div class="card"><p class="ok">配置已保存（已自动备份 .bak），重启防跳后生效。</p></div>' ;;
    mlip)  printf '<div class="card"><p class="ok">百度直连 IP 已更新（已自动备份 .bak），重启防跳后生效。</p></div>' ;;
esac

if [ ! -f "$SEL" ]; then
    printf '<p class="bad">文件不存在</p>'
    html_foot; exit 0
fi

# ---- 百度直连 IP (Ml_iP) 点选 ----
MLIP="$(grep -m1 '^Ml_iP[ ]*=' "$SEL" | sed 's/^[^=]*=[ ]*//;s/;[ ]*$//')"
[ -z "$MLIP" ] && MLIP="(未设置)"
JSTOK="$(printf '%s' "$TOKEN" | js_escape)"
JSFILE="$(printf '%s' "$SEL" | js_escape)"
printf '<div class="card"><h3>百度直连 IP（Ml_iP）</h3>'
printf '<p>当前：<code>%s</code></p>' "$(printf '%s' "$MLIP" | html_escape)"
printf '<p class="hint">从 cloudnproxy.baidu.com 解析到的 IP，点选即写入当前模式文件：</p>'
printf '<div id="iplist"><p class="hint">解析中…</p></div>'
printf '<form method="POST" action="/cgi-bin/action.cgi">'
printf '<input type="hidden" name="token" value="%s">' "$TOKEN"
printf '<input type="hidden" name="op" value="setmlip">'
printf '<input type="hidden" name="file" value="%s">' "$SEL"
printf '<input type="hidden" name="ip" value="cloudnproxy.baidu.com">'
printf '<button type="submit" class="sec">恢复为域名 cloudnproxy.baidu.com</button></form>'
printf '</div>'
printf '<script>\nvar ZTOK='\''%s'\'',ZFILE='\''%s'\'',ZHOST="cloudnproxy.baidu.com";\n' "$JSTOK" "$JSFILE"
cat <<'JSEOF'
fetch('/cgi-bin/ip.cgi?t=dns&h='+ZHOST).then(function(r){return r.text()}).then(function(t){
var box=document.getElementById('iplist');box.innerHTML='';t=(t||'').trim();
if(!t||t==='获取失败'){box.innerHTML='<p class="warn">IP 获取失败，请稍后重试</p>';return;}
t.split(/\s+/).forEach(function(ip){
if(!/^[0-9.]+$/.test(ip))return;
var f=document.createElement('form');f.method='POST';f.action='/cgi-bin/action.cgi';
[['token',ZTOK],['op','setmlip'],['file',ZFILE],['ip',ip]].forEach(function(kv){
var h=document.createElement('input');h.type='hidden';h.name=kv[0];h.value=kv[1];f.appendChild(h);});
var b=document.createElement('button');b.type='submit';b.textContent=ip;f.appendChild(b);
box.appendChild(f);});}).catch(function(){document.getElementById('iplist').innerHTML='<p class="warn">IP 获取失败，请稍后重试</p>'});
JSEOF
printf '</script>\n'

printf '<div class="card"><h3>直接编辑</h3>'
printf '<p class="hint">文件：%s（保存前自动备份为 .bak）<br>' "$SEL"
printf '重点填：cns_server（代理服务器IP:端口）、cns_passwd（密码）、Ml_Host（混淆域名）、Ml_iP。<br>'
printf '保存后需重启防跳生效。</p>'
printf '<form method="POST" action="/cgi-bin/proxy.cgi">'
printf '<input type="hidden" name="token" value="%s">' "$TOKEN"
printf '<input type="hidden" name="file" value="%s">' "$SEL"
printf '<textarea name="content">'
html_escape < "$SEL"
printf '</textarea><br><button type="submit">保存</button></form></div>'
html_foot
