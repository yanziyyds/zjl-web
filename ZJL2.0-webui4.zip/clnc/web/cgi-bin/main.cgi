#!/system/bin/sh
# ZJL WebUI 首页:状态 + 开/关 + IP 检测 + 入口
. /data/clnc/web/cgi-bin/common.sh

TOKEN="$(read_token)"
ST="$(zjl_status)"
MSG="$(query_field msg)"

http_header "text/html"
html_head "ZJL 防跳 · 控制面板"

printf '<div class="card"><p>防跳状态：'
case "$ST" in
    on)      printf '<span class="ok">● 已开启</span>' ;;
    off)     printf '<span class="bad">○ 已关闭</span>' ;;
    partial) printf '<span class="warn">▲ 状态异常（规则与进程不一致）</span>' ;;
    *)       printf '<span class="warn">？ 未知</span>' ;;
esac
printf '</p>'

case "$MSG" in
    opening) printf '<p class="warn">已发送「开启」指令，后台执行中，稍后刷新查看状态。</p>' ;;
    closing) printf '<p class="warn">已发送「关闭」指令，后台执行中，稍后刷新查看状态。</p>' ;;
    saved)   printf '<p class="ok">配置已保存（已自动备份 .bak），重启防跳后生效。</p>' ;;
    mlip)    printf '<p class="ok">百度直连 IP 已更新（已自动备份 .bak），重启防跳后生效。</p>' ;;
    netmode) printf '<p class="ok">网络模式已切换，正在重连，请稍后刷新查看。</p>' ;;
esac

printf '<form method="POST" action="/cgi-bin/action.cgi">'
printf '<input type="hidden" name="token" value="%s">' "$TOKEN"
printf '<input type="hidden" name="op" value="open">'
printf '<button type="submit">开启防跳</button></form>'
printf '<form method="POST" action="/cgi-bin/action.cgi">'
printf '<input type="hidden" name="token" value="%s">' "$TOKEN"
printf '<input type="hidden" name="op" value="close">'
printf '<button type="submit" class="sec">关闭防跳</button></form>'
printf '<form method="GET" action="/cgi-bin/main.cgi">'
printf '<button type="submit" class="sec">刷新状态</button></form>'
printf '</div>'

# IP 检测:JS 异步拉取,避免页面被网络阻塞
printf '<div class="card"><h3>IP 检测</h3>'
printf '<p>出口 IP：<code id="exitip">检测中…</code></p>'
printf '<p>UDP 通道：<code id="udpip">检测中…</code></p>'
printf '<p>cloudnproxy.baidu.com：<code id="dnsip">解析中…</code></p>'
printf '<p class="hint">开启防跳后出口 IP 会变为代理出口、UDP 走隧道，可用来验证是否生效。</p>'
printf '</div>'
printf '<script>'
printf 'function zfill(id,url){fetch(url).then(function(r){return r.text()}).then(function(t){document.getElementById(id).textContent=t||"获取失败"}).catch(function(){document.getElementById(id).textContent="获取失败"})} '
printf 'zfill("exitip","/cgi-bin/ip.cgi?t=exit");'
printf 'zfill("dnsip","/cgi-bin/ip.cgi?t=dns");
zfill("udpip","/cgi-bin/ip.cgi?t=udp");'
printf '</script>'

# 移动网络模式:当前值 + 一键切换
NM="$(netmode_cur)"
NMN="$(netmode_name "$NM")"
printf '<div class="card"><h3>移动网络模式</h3>'
printf '<p>当前：<code>%s</code></p>' "$NMN"
printf '<form method="POST" action="/cgi-bin/action.cgi">'
printf '<input type="hidden" name="token" value="%s">' "$TOKEN"
printf '<input type="hidden" name="op" value="netmode">'
printf '<input type="hidden" name="mode" value="23">'
printf '<button type="submit">锁定 SA（5G 独立组网）</button></form>'
printf '<form method="POST" action="/cgi-bin/action.cgi">'
printf '<input type="hidden" name="token" value="%s">' "$TOKEN"
printf '<input type="hidden" name="op" value="netmode">'
printf '<input type="hidden" name="mode" value="24">'
printf '<button type="submit" class="sec">5G 优先（SA/NSA）</button></form>'
printf '<form method="POST" action="/cgi-bin/action.cgi">'
printf '<input type="hidden" name="token" value="%s">' "$TOKEN"
printf '<input type="hidden" name="op" value="netmode">'
printf '<input type="hidden" name="mode" value="26">'
printf '<button type="submit" class="sec">5G/4G/3G 自动</button></form>'
printf '<form method="POST" action="/cgi-bin/action.cgi">'
printf '<input type="hidden" name="token" value="%s">' "$TOKEN"
printf '<input type="hidden" name="op" value="netmode">'
printf '<input type="hidden" name="mode" value="11">'
printf '<button type="submit" class="sec">仅 4G</button></form>'
printf '<form method="POST" action="/cgi-bin/action.cgi">'
printf '<input type="hidden" name="token" value="%s">' "$TOKEN"
printf '<input type="hidden" name="op" value="netmode">'
printf '<input type="hidden" name="mode" value="7">'
printf '<button type="submit" class="sec">恢复自动</button></form>'
printf '<p class="hint">⚠ 切换后会自动开关一次飞行模式（短暂断网）以生效；锁定 SA 后若当地无 SA 覆盖会无服务，可随时切回自动。拨号盘输入 *#*#4636#*#* 可核对实际模式。</p>'
printf '</div>'

printf '<div class="card"><h3>核心进程</h3><p>'
if ps -A 2>/dev/null | grep -E "[t]iny" | grep -q .; then printf 'tiny <span class="ok">运行中</span>　'; else printf 'tiny <span class="bad">未运行</span>　'; fi
if ps -A 2>/dev/null | grep -E "[c]lnc" | grep -q .; then printf 'clnc <span class="ok">运行中</span>'; else printf 'clnc <span class="bad">未运行</span>'; fi
printf '</p></div>'

printf '<div class="card"><h3>配置</h3>'
printf '<a class="btn sec" href="/cgi-bin/config.cgi">修改防跳配置(.ini)</a>'
printf '<a class="btn sec" href="/cgi-bin/proxy.cgi">修改代理模式(.conf)</a>'
printf '<a class="btn sec" href="/cgi-bin/log.cgi">查看日志</a>'
printf '<p class="hint">改完配置需重启防跳生效。面板地址 http://127.0.0.1:8080 ，仅本机可访问。</p></div>'

html_foot
