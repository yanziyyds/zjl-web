#!/system/bin/sh
# ZJL WebUI:IP 探测接口(只读,供页面 JS 异步调用,不校验 token)
#   /cgi-bin/ip.cgi?t=exit           -> 出口公网 IP(纯文本)
#   /cgi-bin/ip.cgi?t=dns&h=域名      -> 域名解析到的 IPv4,空格分隔(纯文本)
. /data/clnc/web/cgi-bin/common.sh

T="$(query_field t)"
H="$(query_field h)"
# h 只允许域名字符,非法则回退默认域名(防注入)
case "$H" in
    ""|*[!a-zA-Z0-9.-]*) H="cloudnproxy.baidu.com" ;;
esac

MLBOX="$(mlbox_bin)"
http_header "text/plain"

case "$T" in
    dns)
        IPS=""
        if [ -n "$MLBOX" ]; then
            # 优先用 MLBox 直连 DNS 解析(多 IP 都会返回)
            IPS="$("$MLBOX" -dns="-qtype=A -domain=$H" -timeout=5 2>/dev/null \
                | grep -Ev 'timeout|\(\)' | tr ' \t' '\n' \
                | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | sort -u | tr '\n' ' ')"
        fi
        if [ -z "$IPS" ] && [ -n "$MLBOX" ]; then
            # 兜底:DNSPod HTTP API,返回形如 ip;ttl
            _r="$("$MLBOX" -http="http://119.29.29.29/d?dn=$H" -timeout=5 2>&1 \
                | grep -Ev 'timeout|httpGetResponse')"
            _ip="${_r%%;*}"
            valid_ipv4 "$_ip" && IPS="$_ip "
        fi
        _out="$(printf '%s' "$IPS" | sed 's/ $//')"
        printf '%s' "${_out:-获取失败}"
        ;;
    udp)
        # UDP 通道检测:走一次 DNS 查询(UDP),成功返回 OK、解析 IP 与耗时
        # 防跳开启时该查询经 iptables 进隧道,正好测隧道 UDP 通不通
        _ud="www.baidu.com"
        _t0="$(ms_now)"
        _uip=""
        if [ -n "$MLBOX" ]; then
            _uip="$("$MLBOX" -dns="-qtype=A -domain=$_ud" -timeout=5 2>/dev/null \
                | grep -Ev 'timeout|\(\)' | tr ' \t' '\n' \
                | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | sort -u | head -n1)"
        fi
        _t1="$(ms_now)"
        _ms=$((_t1 - _t0))
        if valid_ipv4 "$_uip"; then
            printf 'OK %s (%sms)' "$_uip" "$_ms"
        else
            printf 'FAIL'
        fi
        ;;
    *)
        IP=""
        if [ -n "$MLBOX" ]; then
            # 多个纯 HTTP 接口按序尝试,只接受公网 IP;
            # 隧道里某些接口会返回 127.0.0.1,必须过滤后试下一个
            for _u in "http://pv.sohu.com/cityjson?ie=utf-8" \
                       "http://txt.go.sohu.com/ip/soip" \
                       "http://whois.pconline.com.cn/ipJson.jsp" \
                       "http://myip.ipip.net"; do
                _r="$("$MLBOX" -http="$_u" -timeout=5 2>&1 \
                    | grep -Ev 'timeout|httpGetResponse')"
                _cand="$(printf '%s' "$_r" \
                    | grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | head -n1)"
                if valid_public_ipv4 "$_cand"; then IP="$_cand"; break; fi
            done
        fi
        printf '%s' "${IP:-获取失败}"
        ;;
esac
