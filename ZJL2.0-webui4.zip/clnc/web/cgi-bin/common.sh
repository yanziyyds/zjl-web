#!/system/bin/sh
# ZJL WebUI 公共函数 (POSIX sh, 无 bash 依赖)
WEBDIR="/data/clnc/web"
CGIDIR="$WEBDIR/cgi-bin"
TOKEN_FILE="$WEBDIR/.token"

http_header() {
    # $1 = text/html | text/plain ...
    printf 'Content-Type: %s; charset=utf-8\r\n\r\n' "$1"
}

http_redirect() {
    # $1 = 目标路径
    printf 'Status: 302 Found\r\nLocation: %s\r\n\r\n' "$1"
}

html_head() {
    # $1 = 标题
    printf '<!DOCTYPE html><html><head><meta charset="utf-8">'
    printf '<meta name="viewport" content="width=device-width,initial-scale=1">'
    printf '<title>%s</title>' "$1"
    printf '<style>'
    printf '*{box-sizing:border-box}'
    printf 'body{margin:0;background:#141824;color:#e8eaf2;font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;max-width:720px;margin-left:auto;margin-right:auto;padding-bottom:2em;}'
    printf 'header.top{background:#1e2333;border-bottom:1px solid #2c3348;padding:.85em 1em;font-size:1.1em;font-weight:bold;position:sticky;top:0;z-index:10;}'
    printf 'header.top .ver{color:#8b93a7;font-weight:normal;font-size:.72em;margin-left:.6em;}'
    printf '.wrap{padding:0 .8em;}'
    printf 'h3{font-size:.95em;color:#9fb3d9;margin:1.3em 0 .4em;padding-left:.6em;border-left:3px solid #3b9fe0;}'
    printf '.card{background:#1e2333;border:1px solid #2c3348;border-radius:10px;padding:1em;margin:.7em 0;}'
    printf 'p{line-height:1.7;margin:.45em 0;}'
    printf '.ok{color:#4ade80;font-weight:bold}.bad{color:#f87171;font-weight:bold}.warn{color:#fbbf24;font-weight:bold}'
    printf 'button,.btn{display:block;width:100%%;font-size:1.05em;padding:.75em;margin:.45em 0;border:none;border-radius:9px;background:#3b9fe0;color:#fff;text-decoration:none;text-align:center;cursor:pointer;}'
    printf 'button.sec,.btn.sec{background:#454f66;}'
    printf 'a{color:#6db8f0;}'
    printf '.tabs a{display:inline-block;padding:.55em .9em;margin:.2em .15em;background:#2a3042;border-radius:8px;text-decoration:none;color:#cfd6e4;}'
    printf '.tabs b{display:inline-block;padding:.55em .9em;margin:.2em .15em;background:#3b9fe0;border-radius:8px;color:#fff;}'
    printf 'textarea{width:100%%;height:60vh;font-family:monospace;font-size:14px;background:#10131c;color:#dfe6f5;border:1px solid #2c3348;border-radius:8px;padding:.7em;}'
    printf 'input[type=text]{width:100%%;padding:.7em;border-radius:8px;border:1px solid #2c3348;background:#10131c;color:#fff;font-size:1em;}'
    printf 'pre{background:#10131c;color:#dfe6f5;border:1px solid #2c3348;border-radius:8px;padding:.8em;overflow:auto;white-space:pre-wrap;word-break:break-all;}'
    printf 'code{background:#10131c;border:1px solid #2c3348;padding:.15em .55em;border-radius:5px;font-size:.95em;}'
    printf '.hint{color:#8b93a7;font-size:.85em;}'
    printf 'footer{margin-top:1.6em;text-align:center;color:#8b93a7;font-size:.8em;line-height:2;}'
    printf 'footer a{color:#6db8f0;}'
    printf '</style></head><body>'
    printf '<header class="top">ZJL WebUI<span class="ver">v2.0-webui4</span></header><div class="wrap"><h3>%s</h3>' "$1"
}

html_foot() {
    printf '</div><footer><p><a href="/cgi-bin/main.cgi">← 返回首页</a></p>'
    printf '<p>仅本机访问 · http://127.0.0.1:8080</p></footer></body></html>'
}

html_escape() {
    # stdin -> stdout
    sed -e 's/&/\&amp;/g' -e 's/</\&lt;/g' -e 's/>/\&gt;/g' -e 's/"/\&quot;/g'
}

urldecode() {
    # $1 -> stdout ; 处理 + 和 %XX
    # 可移植实现:逐字符拼成 \0ooo 转义串,最后统一用 printf '%b' 解析；
    # 刻意避开 $( ) 内嵌套 "\\" 双引号(在 dash 下解析异常)
    _in="$1"
    _e=""
    while [ -n "$_in" ]; do
        _c="${_in%"${_in#?}"}"
        _in="${_in#?}"
        case "$_c" in
            "+") _e="${_e} " ;;
            "%")
                _h1="${_in%"${_in#?}"}"; _in="${_in#?}"
                _h2="${_in%"${_in#?}"}"; _in="${_in#?}"
                case "${_h1}${_h2}" in
                    [0-9A-Fa-f][0-9A-Fa-f])
                        _oct="$(printf '%o' "0x${_h1}${_h2}")"
                        while [ "${#_oct}" -lt 3 ]; do _oct="0${_oct}"; done
                        _e="${_e}\\0${_oct}"
                        ;;
                    *) _e="${_e}%${_h1}${_h2}" ;;
                esac
                ;;
            "\\") _e="${_e}\\\\" ;;
            *) _e="${_e}${_c}" ;;
        esac
    done
    printf '%b' "$_e"
}

read_post() {
    if [ -n "$CONTENT_LENGTH" ] && [ "$CONTENT_LENGTH" -gt 0 ] 2>/dev/null; then
        POST_DATA="$(head -c "$CONTENT_LENGTH")"
    else
        POST_DATA=""
    fi
}

# 从 & 分隔的串中取字段并 urldecode: $1=串 $2=字段名 -> stdout
field_of() {
    _str="$1"; _name="$2"
    _v="$(printf '%s' "$_str" | tr '&' '\n' | grep -m1 "^${_name}=" | cut -d= -f2-)"
    urldecode "$_v"
}

post_field() { field_of "$POST_DATA" "$1"; }
query_field() { field_of "$QUERY_STRING" "$1"; }

read_token() { cat "$TOKEN_FILE" 2>/dev/null; }

check_token() {
    # $1 = 表单 token
    _want="$(read_token)"
    [ -n "$1" ] && [ -n "$_want" ] && [ "$1" = "$_want" ]
}

deny() {
    http_header "text/html"
    html_head "拒绝访问"
    printf '<p class="bad">Token 无效或已过期，请刷新页面重试。</p>'
    html_foot
    exit 0
}

zjl_bin() {
    # 定位 ZJL 主脚本(目录名含 #U 转义,用 glob;只取第一个)
    for _f in /data/clnc/*/ZJL; do
        [ -f "$_f" ] && { echo "$_f"; return 0; }
    done
}

# 防跳状态: 输出 on|off|partial
zjl_status() {
    _rule=0; _proc=0
    if iptables -t mangle -S OUTPUT 2>/dev/null | head -n1 | grep -q "\-P OUTPUT DROP"; then
        _rule=1
    fi
    if ps -A 2>/dev/null | grep -E "[t]iny|[c]lnc" | grep -q .; then
        _proc=1
    fi
    if [ "$_rule" = 1 ] && [ "$_proc" = 1 ]; then
        echo "on"
    elif [ "$_rule" = 0 ] && [ "$_proc" = 0 ]; then
        echo "off"
    else
        echo "partial"
    fi
}

# 定位 MLBox 二进制(模块自带,用于 DNS/HTTP 探测)
mlbox_bin() {
    for _f in /data/clnc/*/MLBox; do
        [ -x "$_f" ] && { echo "$_f"; return 0; }
    done
}

# 跳转 URL 编码:只处理 % # 空格(% 必须先转,避免二次编码)
urlencode_path() {
    printf '%s' "$1" | sed -e 's/%/%25/g' -e 's/#/%23/g' -e 's/ /%20/g'
}

# IPv4 合法性校验: $1 -> return 0 合法
# 注意:内部变量用 _v4 前缀,避免覆盖调用者的同名变量
valid_ipv4() {
    case "$1" in *[!0-9.]*) return 1;; esac
    _v4s="$1."; _v4n=0
    while [ -n "$_v4s" ]; do
        _v4o="${_v4s%%.*}"; _v4s="${_v4s#*.}"
        _v4n=$((_v4n + 1))
        case "$_v4o" in ""|*[!0-9]*) return 1;; esac
        if [ "$_v4o" -gt 255 ] 2>/dev/null; then return 1; fi
    done
    [ "$_v4n" -eq 4 ]
}

# 公网 IPv4 校验:先过 valid_ipv4,再排除回环/私网/保留段
# (隧道里某些查 IP 接口会返回 127.0.0.1,必须过滤)
# 注意:内部变量用 _p4 前缀,避免覆盖调用者的同名变量
valid_public_ipv4() {
    valid_ipv4 "$1" || return 1
    _p4a="${1%%.*}"
    _p4rest="${1#*.}"; _p4b="${_p4rest%%.*}"
    case "$_p4a.$_p4b" in
        10.*|127.*|192.168|169.254|0.*) return 1 ;;
    esac
    if [ "$_p4a" = 172 ]; then
        case "$_p4b" in 1[6-9]|2[0-9]|3[0-1]) return 1;; esac
    fi
    if [ "$_p4a" = 100 ]; then
        case "$_p4b" in 6[4-9]|7[0-9]|8[0-9]|9[0-9]|10[0-9]|11[0-9]|12[0-7]) return 1;; esac
    fi
    return 0
}

# 毫秒时间戳(尽量精确);date 不支持 %N 时回退到秒级精度
# 用字符串截断做纳秒->毫秒,避免 32 位 shell 算术溢出
ms_now() {
    _msn="$(date +%s%N 2>/dev/null)"
    case "$_msn" in
        *[!0-9]*|"")
            _msn="$(date +%s 2>/dev/null)"
            case "$_msn" in
                *[!0-9]*|"") _msn="0" ;;
                *) _msn="${_msn}000" ;;
            esac
            ;;
        *) _msn="${_msn%??????}" ;;  # 去掉纳秒末 6 位 -> 毫秒
    esac
    [ -n "$_msn" ] || _msn=0
    printf '%s' "$_msn"
}

# JS 单引号字符串转义: stdin -> stdout
js_escape() {
    sed -e 's/\\/\\\\/g' -e "s/'/\\\\'/g" | tr '\n' ' '
}

# ---- 移动网络模式 ----
# 当前 preferred_network_mode:输出数字;失败输出空
netmode_cur() {
    settings get global preferred_network_mode 2>/dev/null | tr -d ' \t\r\n'
}
# 模式数字 -> 中文名(AOSP RILConstants)
netmode_name() {
    case "$1" in
        23) printf '5G SA 锁定' ;;
        24) printf '5G 优先' ;;
        26) printf '5G/4G/3G/2G 自动' ;;
        11) printf '仅 4G' ;;
        9)  printf '4G/3G/2G 自动' ;;
        7)  printf '自动（全球）' ;;
        ''|null) printf '读取失败' ;;
        *) printf '未知（%s）' "$1" ;;
    esac
}
