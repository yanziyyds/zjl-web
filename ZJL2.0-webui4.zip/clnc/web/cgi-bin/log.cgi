#!/system/bin/sh
# ZJL WebUI:查看日志
. /data/clnc/web/cgi-bin/common.sh

http_header "text/html"
html_head "日志"

printf '<div class="card"><h3>最近一次 开/关 执行输出 (action.log)</h3><pre>'
if [ -f "$WEBDIR/action.log" ]; then html_escape < "$WEBDIR/action.log" | tail -c 20000; else printf '(空)'; fi
printf '</pre></div>'

printf '<div class="card"><h3>Web 面板日志 (web.log)</h3><pre>'
if [ -f "$WEBDIR/web.log" ]; then html_escape < "$WEBDIR/web.log" | tail -c 20000; else printf '(空)'; fi
printf '</pre></div>'

printf '<div class="card"><h3>面板进程</h3><pre>'
ps -A 2>/dev/null | grep "[h]ttpd" | html_escape
printf '</pre></div>'

html_foot
