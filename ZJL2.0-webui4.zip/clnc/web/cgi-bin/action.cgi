#!/system/bin/sh
# ZJL WebUI:执行 开启/关闭(后台运行,立即302跳回首页)
. /data/clnc/web/cgi-bin/common.sh

if [ "$REQUEST_METHOD" != "POST" ]; then
    http_redirect "/cgi-bin/main.cgi"
    exit 0
fi

read_post
OP="$(post_field op)"
TK="$(post_field token)"
check_token "$TK" || deny

BIN="$(zjl_bin)"
LOG="$WEBDIR/action.log"
: > "$LOG"
echo "=== $(date '+%F %T') op=$OP ===" >> "$LOG"
# 手机上固定用 /system/bin/sh；兜底用 PATH 中的 sh
if [ -x /system/bin/sh ]; then _SH=/system/bin/sh; else _SH=sh; fi

case "$OP" in
    open)
        ( $_SH "$BIN" -o >>"$LOG" 2>&1 < /dev/null & )
        http_redirect "/cgi-bin/main.cgi?msg=opening"
        ;;
    close)
        ( $_SH "$BIN" -c >>"$LOG" 2>&1 < /dev/null & )
        http_redirect "/cgi-bin/main.cgi?msg=closing"
        ;;
    setmlip)
        # 把解析到的 IP(或默认域名)写入指定 .conf 的 Ml_iP 行
        IPV="$(post_field ip)"
        TARGET="$(post_field file)"
        case "$TARGET" in
            /data/clnc/*.conf) ;;
            *) http_header "text/html"; html_head "出错"; printf '<p class="bad">非法文件路径</p>'; html_foot; exit 0 ;;
        esac
        if [ ! -f "$TARGET" ]; then
            http_header "text/html"; html_head "出错"; printf '<p class="bad">文件不存在</p>'; html_foot; exit 0
        fi
        # 值只允许合法 IPv4 或默认域名
        OKV=0
        if [ "$IPV" = "cloudnproxy.baidu.com" ]; then
            OKV=1
        else
            valid_ipv4 "$IPV" && OKV=1
        fi
        if [ "$OKV" != 1 ]; then
            http_header "text/html"; html_head "出错"; printf '<p class="bad">非法 IP 值</p>'; html_foot; exit 0
        fi
        if ! grep -q '^Ml_iP[ ]*=' "$TARGET"; then
            http_header "text/html"; html_head "出错"; printf '<p class="bad">该文件没有 Ml_iP 行</p>'; html_foot; exit 0
        fi
        echo "=== $(date '+%F %T') op=setmlip ip=$IPV file=$TARGET ===" >> "$LOG"
        cp -f "$TARGET" "$TARGET.bak"
        sed 's|^Ml_iP[ ]*=.*|Ml_iP = '"$IPV"';|' "$TARGET" > "$TARGET.tmp" \
            && mv -f "$TARGET.tmp" "$TARGET"
        http_redirect "/cgi-bin/proxy.cgi?f=$(urlencode_path "$TARGET")&msg=mlip"
        ;;
    netmode)
        # 切换移动网络模式(白名单校验,仅允许 AOSP 定义的合法值)
        NMODE="$(post_field mode)"
        case "$NMODE" in
            7|11|23|24|26) ;;
            *) http_header "text/html"; html_head "出错"; printf '<p class="bad">非法网络模式</p>'; html_foot; exit 0 ;;
        esac
        echo "=== $(date '+%F %T') op=netmode mode=$NMODE ===" >> "$LOG"
        (
            settings put global preferred_network_mode "$NMODE" 2>/dev/null
            settings put global preferred_network_mode1 "$NMODE" 2>/dev/null
            # 飞行模式开关一次,强制重新注册网络以生效
            settings put global airplane_mode_on 1 2>/dev/null
            am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true >/dev/null 2>&1
            sleep 2
            settings put global airplane_mode_on 0 2>/dev/null
            am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false >/dev/null 2>&1
            echo "netmode $NMODE applied" >> "$LOG"
        ) >>"$LOG" 2>&1 &
        http_redirect "/cgi-bin/main.cgi?msg=netmode"
        ;;
    *)
        http_redirect "/cgi-bin/main.cgi"
        ;;
esac
