# 开机之后执行
#!/system/bin/sh
# 不要假设您的模块将位于何处。
# 如果您需要知道此脚本和模块的放置位置，请使用$MODDIR
# 这将确保您的模块仍能正常工作
# 即使Magisk将来更改其挂载点
MODDIR=${0%/*}

# 判断防跳是否存在 不存在就复制
[ -d /data/clnc/ ] || cp -af ${0%/*}/clnc /data/clnc

# ---------- ZJL Web 控制面板:同步文件并启动(仅 127.0.0.1 可访问) ----------
if [ -d "${MODDIR}/clnc/web" ]; then
    mkdir -p /data/clnc/web/cgi-bin
    cp -af "${MODDIR}/clnc/web/index.html" /data/clnc/web/index.html
    cp -af "${MODDIR}/clnc/web/start_web.sh" /data/clnc/web/start_web.sh
    cp -af "${MODDIR}/clnc/web/cgi-bin/." /data/clnc/web/cgi-bin/
    chmod 755 /data/clnc/web/start_web.sh /data/clnc/web/cgi-bin/*.cgi 2>/dev/null
    # 后台启动面板,不阻塞后面的防跳启动流程
    /system/bin/sh /data/clnc/web/start_web.sh >/dev/null 2>&1 &
fi
# ---------- Web 面板结束 ----------

# 一直循环直到开启了数据没开启WiFi的情况下才会启动防跳
while true; do
    # 判断是否已经获取到网卡
    if [[ ! ${net_card} ]]; then
        # 获取流量网卡
        net_card=`dumpsys connectivity | grep "NetworkAgentInfo{" | grep "type: MOBILE" | grep -Ev "(extra: ims)|(extra: IMS)" | grep -o "InterfaceName: [^ ]*" | grep -o "[^: ]*$"`
        net_card=${net_card:-`dumpsys netstats | grep -i "iface=" | grep "metered=true" | grep -Eio -m 1 "rmnet[^ ]*|ccmni[^ ]*"`}
        net_card=${net_card:-`ip route | grep -Eio -m 1 "rmnet[^ ]*|ccmni[^ ]*"`}
        net_card=${net_card:-`ifconfig | grep -Ei -A 1 "rmnet[^ ]*|ccmni[^ ]*" | grep -wB 1 "inet" | grep -Eo "rmnet[^ ]*|ccmni[^ ]*"`}
    fi
    
    # 判断是否能获取到内网IP
    [[ `ifconfig | grep -w -A 1 "${net_card}" | grep -o "inet addr:[^ ]*" | grep -o "[^: ]*$"` ]] && break || sleep 3
done

# 开启防跳
/system/bin/sh /data/clnc/*/ZJL -o

# 此脚本将在late_start service 模式执行

